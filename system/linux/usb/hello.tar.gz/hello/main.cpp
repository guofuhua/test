#if 1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/un.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <linux/types.h>
#include <linux/netlink.h>
#include <errno.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/in.h>

extern int test_main();

#define UEVENT_BUFFER_SIZE 2048

static int init_hotplug_sock()
{
    const int buffersize = 1024;
    int ret;

    struct sockaddr_nl snl;
    bzero(&snl, sizeof(struct sockaddr_nl));
    snl.nl_family = AF_NETLINK;
    snl.nl_pid = getpid();
    snl.nl_groups = 1;

    int s = socket(PF_NETLINK, SOCK_DGRAM, NETLINK_KOBJECT_UEVENT);
    if (s == -1)
    {
        perror("socket");
        return -1;
    }
    setsockopt(s, SOL_SOCKET, SO_RCVBUF, &buffersize, sizeof(buffersize));

    ret = bind(s, (struct sockaddr *)&snl, sizeof(struct sockaddr_nl));
    if (ret < 0)
    {
        perror("bind");
        close(s);
        return -1;
    }

    return s;
}

int main(int argc, char* argv[])
{
    int hotplug_sock = init_hotplug_sock();
    test_main();

    while(1)
    {
        /* Netlink message buffer */
        char buf[UEVENT_BUFFER_SIZE * 2] = {0};
        recv(hotplug_sock, &buf, sizeof(buf), 0);
        printf("%s\n", buf);

        /* USB 设备的插拔会出现字符信息，通过比较不同的信息确定特定设备的插拔，在这添加比较代码 */
    }
    return 0;

}







#else





//#include <QCoreApplication>
//#include <QDebug>
#include "storage.h"
#include <stdio.h>
#include <pthread.h>
#include <unistd.h>
#include <assert.h>
#include "ffmpegdecode.h"
#include "threadpool/threadpool.h"

extern pthread_rwlock_t rwlock;
extern MONITOR_RECORD g_record;

int tasks = 0, done = 0;
pthread_mutex_t lock;

void dummy_task(void *arg) {
    usleep(10000);
    pthread_mutex_lock(&lock);
    /* 记录成功完成的任务数 */
    done++;
    pthread_mutex_unlock(&lock);
}

int main(int argc, char *argv[])
{
    //    QCoreApplication a(argc, argv);

    int thread_count = 32;
    int queue_size = 256;
    threadpool_t *pool;
    TAVInfo avInfo[MAX_CHANNEL];
    memset(avInfo, 0, sizeof(TAVInfo) * MAX_CHANNEL);
    storage::init();

    pthread_rwlock_wrlock(&rwlock);
    for (int i = 0; i < g_record.channel_count; i++) {
        avInfo[i].channel_id = g_record.channel[i].channel_id;
        strncpy(avInfo[i].rtsp, g_record.channel[i].substream, RTSP_PATH_LEN);
        strncpy(avInfo[i].save, g_record.channel[i].save_sub_path, SAVE_PATH_LEN);
        avInfo[i].callback = StreamPacketCallback;
        avInfo[i].file = NULL;
        avInfo[i].duration_sec = 30;
    }
    pthread_rwlock_unlock(&rwlock);

    /* 初始化互斥锁 */
    pthread_mutex_init(&lock, NULL);

    /* 断言线程池创建成功 */
    assert((pool = threadpool_create(thread_count, queue_size, 0)) != NULL);
    fprintf(stderr, "Pool started with %d threads and "
            "queue size of %d\n", thread_count, queue_size);
    threadpool_add(pool, StreamProcess, (void *)&avInfo[0], 0);
    threadpool_add(pool, StreamProcess, (void *)&avInfo[1], 0);
    threadpool_add(pool, StreamProcess, (void *)&avInfo[2], 0);
    threadpool_add(pool, StreamProcess, (void *)&avInfo[3], 0);
    threadpool_add(pool, StreamProcess, (void *)&avInfo[4], 0);

    /* 只要任务队列还没满，就一直添加 */
    while(threadpool_add(pool, &dummy_task, NULL, 0) == 0) {
        pthread_mutex_lock(&lock);
        tasks++;
        pthread_mutex_unlock(&lock);
    }

    fprintf(stderr, "Added %d tasks\n", tasks);


    /* 这时候销毁线程池,0 代表 immediate_shutdown */
    assert(threadpool_destroy(pool, 0) == 0);

    return 0;

    //    qDebug() << "hello world!(Qt)";
    //    char rtsp_url[] = {"rtsp://192.168.60.21/chn0"};

    //    StreamProcess(rtsp_url, NULL, NULL);
    
    return 0;
}
#endif
